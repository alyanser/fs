/* rv64-emu -- Simple 64-bit RISC-V simulator
 *
 *    inst-formatter.cc - RISC-V instruction printer (disassembler)
 *
 * Copyright (C) 2016,2018  Leiden University, The Netherlands.
 */

#include "inst-decoder.h"

#include <functional>
#include <map>
#include <iostream>

std::ostream &
operator<<(std::ostream &os, const Register reg){
	switch(reg){
		case Register::R0 : os << "r0"; break;
		case Register::R1 : os << "r1"; break;
		case Register::R2 : os << "r2"; break;
		case Register::R3 : os << "r3"; break;
		case Register::R4 : os << "r4"; break;
		case Register::R5 : os << "r5"; break;
		case Register::R6 : os << "r6"; break;
		case Register::R7 : os << "r7"; break;
		case Register::R8 : os << "r8"; break;
		case Register::R9 : os << "r9"; break;
		case Register::R10 : os << "r10"; break;
		case Register::R11 : os << "r11"; break;
		case Register::R12 : os << "r12"; break;
		case Register::R13 : os << "r13"; break;
		case Register::R14 : os << "r14"; break;
		case Register::R15 : os << "r15"; break;
		case Register::R16 : os << "r16"; break;
		case Register::R17 : os << "r17"; break;
		case Register::R18 : os << "r18"; break;
		case Register::R19 : os << "r19"; break;
		case Register::R20 : os << "r20"; break;
		case Register::R21 : os << "r21"; break;
		case Register::R22 : os << "r22"; break;
		case Register::R23 : os << "r23"; break;
		case Register::R24 : os << "r24"; break;
		case Register::R25 : os << "r25"; break;
		case Register::R26 : os << "r26"; break;
		case Register::R27 : os << "r27"; break;
		case Register::R28 : os << "r28"; break;
		case Register::R29 : os << "r29"; break;
		case Register::R30 : os << "r30"; break;
		case Register::R31 : os << "r31"; break;
	}
	return os;
}

std::ostream &
operator<<(std::ostream &os, const Instruction ins){
	switch(ins){
		case Instruction::J : os << "l.j"; break;
		case Instruction::JAL : os << "l.jal"; break;
		case Instruction::BNF : os << "l.bnf"; break;
		case Instruction::BF : os << "l.bf"; break;
		case Instruction::NOP : os << "l.nop"; break;
		case Instruction::MOVHI : os << "l.movhi"; break;
		case Instruction::SYS : os << "l.sys"; break;
		case Instruction::RFE : os << "l.rfe"; break;
		case Instruction::JR : os << "l.jr"; break;
		case Instruction::JALR : os << "l.jalr"; break;
		case Instruction::LWZ : os << "l.lwz"; break;
		case Instruction::LWS : os << "l.lws"; break;
		case Instruction::LBZ : os << "l.lbz"; break;
		case Instruction::LBS : os << "l.lbs"; break;
		case Instruction::LHZ : os << "l.lhz"; break;
		case Instruction::LHS : os << "l.lhs"; break;
		case Instruction::ADDI : os << "l.addi"; break;
		case Instruction::ADDIC : os << "l.addic"; break;
		case Instruction::ANDI : os << "l.andi"; break;
		case Instruction::ORI : os << "l.ori"; break;
		case Instruction::XORI : os << "l.xori"; break;
		case Instruction::MULI : os << "l.muli"; break;
		case Instruction::MFSPR : os << "l.mfspr"; break;
		case Instruction::SLLI : os << "l.slli"; break;
		case Instruction::SRLI : os << "l.srli"; break;
		case Instruction::SRAI : os << "l.srai"; break;
		case Instruction::MTSPR : os << "l.mtspr"; break;
		case Instruction::SW : os << "l.sw"; break;
		case Instruction::SB : os << "l.sb"; break;
		case Instruction::SH : os << "l.sh"; break;
		case Instruction::ADD : os << "l.add"; break;
		case Instruction::ADDC : os << "l.addc"; break;
		case Instruction::SUB : os << "l.sub"; break;
		case Instruction::AND : os << "l.and"; break;
		case Instruction::OR : os << "l.or"; break;
		case Instruction::XOR : os << "l.xor"; break;
		case Instruction::MUL : os << "l.mul"; break;
		case Instruction::SLL : os << "l.sll"; break;
		case Instruction::SRL : os << "l.srl"; break;
		case Instruction::SRA : os << "l.sra"; break;
		case Instruction::MULU : os << "l.mulu"; break;
		case Instruction::SFEQ : os << "l.sf eq"; break;
		case Instruction::SFNE : os << "l.sf ne"; break;
		case Instruction::SFGTU : os << "l.sf gtu"; break;
		case Instruction::SFGEU : os << "l.sf geu"; break;
		case Instruction::SFLTU : os << "l.sf ltu"; break;
		case Instruction::SFLEU : os << "l.sf leu"; break;
		case Instruction::SFGTS : os << "l.sf gts"; break;
		case Instruction::SFGES : os << "l.sf ges"; break;
		case Instruction::SFLTS : os << "l.sf lts"; break;
		case Instruction::SFLES : os << "l.sf les"; break;
		case Instruction::SFEQI : os << "l.sfi eq"; break;
		case Instruction::SFNEI : os << "l.sfi ne"; break;
		case Instruction::SFGTUI : os << "l.sfi gtu"; break;
		case Instruction::SFGEUI : os << "l.sfi geu"; break;
		case Instruction::SFLTUI : os << "l.sfi ltu"; break;
		case Instruction::SFLEUI : os << "l.sfi leu"; break;
		case Instruction::SFGTSI : os << "l.sfi gts"; break;
		case Instruction::SFGESI : os << "l.sfi ges"; break;
		case Instruction::SFLTSI : os << "l.sfi lts"; break;
		case Instruction::SFLESI : os << "l.sfi les"; break;
		case Instruction::ROR : os << "l.ror"; break;
		case Instruction::DIV : os << "l.div"; break;
		case Instruction::DIVU : os << "l.divu"; break;
		case Instruction::CMOV : os << "l.cmov"; break;
	}

	return os;
}

std::ostream &
operator<<(std::ostream &os, const InstructionDecoder &decoder)
{
	os << decoder.instruction << ' ';

	switch(decoder.instructionType){

		case InstructionType::I : {

			switch(decoder.instruction){ // some instructions in expected output contain '$' :(
				case Instruction::JAL: break;
				case Instruction::BNF: break;
				default: os << '$';
			}
			os << decoder.immediate;
			break;
		}

		case InstructionType::R1 : {
			os << decoder.dReg << ", " << decoder.aReg << ", " << decoder.bReg;
			break;
		}

		case InstructionType::R2 : {
			os << decoder.dReg << ", " << decoder.aReg << ", $" << decoder.immediate;
			break;
		}

		case InstructionType::R3 : {
			// hacky print aReg twice because there seems to be a bug in test case
			// expect outpu contains 3 registers while there shoudl just be bReg
			os << decoder.aReg << ", " << decoder.aReg << ", " << decoder.bReg;
			break;
		}

		case InstructionType::RI : {
			switch(decoder.instruction){
				case Instruction::LWZ : {
					os << decoder.dReg << ", " << static_cast<int16_t>(decoder.immediate) << "(" << decoder.aReg << ")";
				}
				return os;
			}

			os << decoder.dReg << ", " << decoder.aReg << ", $";

			switch(decoder.instruction){ // if it's a bit operation, print the immediate as unsigned
				case Instruction::ANDI: [[fallthrough]];
				case Instruction::ORI: [[fallthrough]];
				case Instruction::XORI: {
					os << decoder.immediate;
					break;
				}
				default: {
					os << static_cast<int16_t>(decoder.immediate);
				}
			}
			break;
		}

		case InstructionType::RI2 : {
			os << decoder.bReg << ", " << static_cast<int16_t>(decoder.immediate) << "(" << decoder.aReg << ')';
			break;
		}

		case InstructionType::RSF : {
			os << decoder.aReg << ", " << decoder.bReg;
			break;
		}

		case InstructionType::RSFI : {
			os << decoder.aReg << ", $" << static_cast<int16_t>(decoder.immediate);
			break;
		}

		case InstructionType::END_MARKER : {
			break;
		}
	}

	return os;
}
