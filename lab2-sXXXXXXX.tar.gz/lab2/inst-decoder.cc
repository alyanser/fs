/* rv64-emu -- Simple 64-bit RISC-V simulator
 *
 *    inst-decoder.cc - RISC-V instruction decoder.
 *
 * Copyright (C) 2016,2019  Leiden University, The Netherlands.
 *
 */

#include "inst-decoder.h"

#include <iostream>
#include <unordered_map>
#include <bitset>

/*
 * Class InstructionDecoder -- helper class for getting specific
 * information from the decoded instruction.
 */

void
InstructionDecoder::setInstructionWord(const uint32_t instructionWord)
{
  this->instructionWord = instructionWord;

	if(instructionWord == TestEndMarker){
		instructionType = InstructionType::END_MARKER;
	}else{
		decode();
	}
}

uint32_t
InstructionDecoder::getInstructionWord() const
{
	return instructionWord;
}

RegNumber
InstructionDecoder::getA() const
{
	return static_cast<RegNumber>(aReg);
}

RegNumber
InstructionDecoder::getB() const
{
	return static_cast<RegNumber>(bReg);
}

RegNumber
InstructionDecoder::getD() const
{
	return static_cast<RegNumber>(dReg);
}

uint8_t
InstructionDecoder::getOpcode() const {
  return static_cast<uint8_t>(opcode);
}

uint32_t
InstructionDecoder::getImmediate() const {
  return immediate;
}

uint8_t
InstructionDecoder::getFunctionCode() const {
  return functionCode;
}

InstructionType
InstructionDecoder::getInstructionType() const {
	return instructionType;
}

Instruction
InstructionDecoder::getInstruction() const {
	return instruction;
}

constexpr auto dRegMask = 0x3e00000;
constexpr auto aRegMask = 0x1f0000;
constexpr auto bRegMask = 0xf800;

uint32_t extractBits(const uint32_t instruction, const std::ptrdiff_t startBitIdx, std::ptrdiff_t bitCnt){
	uint32_t bitMask = 0;

	for(std::ptrdiff_t i = startBitIdx; bitCnt; --i, --bitCnt){
		bitMask |= (1 << i);
	}

	return instruction & bitMask;
}

enum class RegisterType {
	A,
	B,
	D
};

Register extractRegister(const uint32_t instruction, const RegisterType regType){

	switch(regType){
		case RegisterType::B : return Register((instruction & bRegMask) >> 11);
		case RegisterType::A : return Register((instruction & aRegMask) >> 16);
		case RegisterType::D : return Register((instruction & dRegMask) >> 21);
	}

	throw std::runtime_error("internal: invalid register type argument for decoding");
};

struct IMetadata {
	uint32_t immediate{};
};

struct R1Metadata {
	uint16_t functionCode{};
	Register aReg{};
	Register bReg{};
	Register dReg{};
};

struct R2Metadata {
	uint16_t functionCode{};
	Register aReg{};
	Register dReg{};
	uint32_t immediate{};
};

struct R3Metadata {
	Register bReg{};
};

struct RIMetadata {
	uint16_t immediate{};
	Register dReg{};
	Register aReg{};
};

struct RI2Metadata {
	uint16_t immediate{};
	Register aReg{};
	Register bReg{};
};

struct RSFMetadata {
	uint16_t functionCode{};
	Register aReg{};
	Register bReg{};
};

struct RSFIMetadata {
	uint16_t immediate{};
	uint16_t functionCode{};
	Register aReg{};
};

IMetadata extractITypeInstruction(const uint32_t instruction){
	return IMetadata{
		extractBits(instruction, 25, 26)
	};
}

R3Metadata extractR3TypeInstruction(const uint32_t instruction){
	return{
		extractRegister(instruction, RegisterType::B),
	};
}

R1Metadata extractR1TypeInstruction(const uint32_t instruction){
	return{
		static_cast<uint16_t>(extractBits(instruction, 10, 11)),
		extractRegister(instruction, RegisterType::A),
		extractRegister(instruction, RegisterType::B),
		extractRegister(instruction, RegisterType::D)
	};
}

R2Metadata extractR2TypeInstruction(const uint32_t instruction){
	return{
		static_cast<uint16_t>(extractBits(instruction, 7, 2) >> 6),
		extractRegister(instruction, RegisterType::A),
		extractRegister(instruction, RegisterType::D),
		static_cast<uint16_t>(extractBits(instruction, 5, 6))
	};
}

RIMetadata extractRITypeInstruction(const uint32_t instruction){
	return RIMetadata{
		static_cast<uint16_t>(extractBits(instruction, 15, 16)),
		extractRegister(instruction, RegisterType::D),
		extractRegister(instruction, RegisterType::A),
	};
}

RI2Metadata extractRI2TypeInstruction(const uint32_t instruction){
	return{
		static_cast<uint16_t>(extractBits(instruction, 10, 11) | (extractBits(instruction, 25, 5)) >> 10),
		extractRegister(instruction, RegisterType::A),
		extractRegister(instruction, RegisterType::B),
	};
}

RSFMetadata extractRSFTypeInstruction(const uint32_t instruction){
	return{
		static_cast<uint16_t>(extractBits(instruction, 25, 5) >> 21),
		extractRegister(instruction, RegisterType::A),
		extractRegister(instruction, RegisterType::B),
	};
}

RSFIMetadata extractRSFITypeInstruction(const uint32_t instruction){
	return{
		static_cast<uint16_t>(extractBits(instruction, 15, 16)),
		static_cast<uint16_t>(extractBits(instruction, 25, 5) >> 21),
		extractRegister(instruction, RegisterType::A),
	};
}

void
InstructionDecoder::decode(){

	const static std::unordered_map<uint8_t, InstructionType> instructionMapping {
		std::make_pair(0x00, InstructionType::I),
		std::make_pair(0x01, InstructionType::I),
		std::make_pair(0x03, InstructionType::I),
		std::make_pair(0x04, InstructionType::I),
		std::make_pair(0x05, InstructionType::I),
		std::make_pair(0x06, InstructionType::RI),
		std::make_pair(0x08, InstructionType::I),
		std::make_pair(0x09, InstructionType::I),
		std::make_pair(0x11, InstructionType::R3),
		std::make_pair(0x12, InstructionType::R3),
		std::make_pair(0x21, InstructionType::RI),
		std::make_pair(0x22, InstructionType::RI),
		std::make_pair(0x23, InstructionType::RI),
		std::make_pair(0x24, InstructionType::RI),
		std::make_pair(0x25, InstructionType::RI),
		std::make_pair(0x26, InstructionType::RI),
		std::make_pair(0x27, InstructionType::RI),
		std::make_pair(0x28, InstructionType::RI),
		std::make_pair(0x29, InstructionType::RI),
		std::make_pair(0x2A, InstructionType::RI),
		std::make_pair(0x2B, InstructionType::RI),
		std::make_pair(0x2C, InstructionType::RI),
		std::make_pair(0x2D, InstructionType::RI),
		std::make_pair(0x2E, InstructionType::R2),
		std::make_pair(0x30, InstructionType::RI2),
		std::make_pair(0x35, InstructionType::RI2),
		std::make_pair(0x36, InstructionType::RI2),
		std::make_pair(0x37, InstructionType::RI2),
		std::make_pair(0x38, InstructionType::R1),
		std::make_pair(0x39, InstructionType::RSF),
		std::make_pair(0x2f, InstructionType::RSFI),
	};

	constexpr uint32_t opcodeMask = 0xfc000000;
	opcode = (instructionWord & opcodeMask) >> 26;

	if(!instructionMapping.count(opcode)){
		throw IllegalInstruction("invalid or unimplemented opcode. opcode: " + std::to_string(opcode));
	}


	switch(instructionType = instructionMapping.at(opcode)){

		case InstructionType::I : {
			immediate = extractITypeInstruction(instructionWord).immediate;

			switch(opcode){
				case 0x0 : instruction = Instruction::J; return;
				case 0x1 : instruction = Instruction::JAL; return;
				case 0x3 : instruction = Instruction::BNF; return;
				case 0x4 : instruction = Instruction::BF; return;
				case 0x5 : instruction = Instruction::NOP, immediate = extractBits(instructionWord, 15, 16); return;
				case 0x8 : instruction = Instruction::SYS; return;
				case 0x9 : instruction = Instruction::RFE; return;
			}
			break;
		}

		case InstructionType::R1 : {
			const auto [functionCode, aReg, bReg, dReg] = extractR1TypeInstruction(instructionWord);
			this->functionCode = functionCode;
			this->aReg = aReg;
			this->bReg = bReg;
			this->dReg = dReg;

			if(this->functionCode > 0x8){
				constexpr uint32_t leftOpcodeMask = 0x3c0;
				constexpr uint32_t rightOpcodeMask = 0xf;
				this->functionCode = ((leftOpcodeMask & functionCode) >> 2) | (rightOpcodeMask & functionCode);
			}

			switch(this->functionCode){
				case 0x0 : instruction = Instruction::ADD; return;
				case 0x1 : instruction = Instruction::ADDC; return;
				case 0x2 : instruction = Instruction::SUB; return;
				case 0x3 : instruction = Instruction::AND; return;
				case 0x4 : instruction = Instruction::OR; return;
				case 0x5 : instruction = Instruction::XOR; return;
				case 0x6 : instruction = Instruction::MUL; return;
				case 0x8 : instruction = Instruction::SLL; return;
				case 0x18 : instruction = Instruction::SRL; return;
				case 0x28 : instruction = Instruction::SRA; return;
				case 0xb : instruction = Instruction::MULU; return;
				case 0x38 : instruction = Instruction::ROR; return;
				case 0x9 : instruction = Instruction::DIV; return;
				case 0xa : instruction = Instruction::DIVU; return;
				case 0xe : instruction = Instruction::CMOV; return;
			}
			break;
		}

		case InstructionType::R2 : {
			auto [functionCode, aReg, dReg, immediate] = extractR2TypeInstruction(instructionWord);
			this->functionCode = functionCode;
			this->aReg = aReg;
			this->dReg = dReg;
			this->immediate = immediate;

			switch(functionCode){
				case 0x0 : instruction = Instruction::SLLI; return;
				case 0x1 : instruction = Instruction::SRLI; return;
				case 0x2 : instruction = Instruction::SRAI; return;
			}
			break;
		}

		case InstructionType::R3 : {
			bReg = extractR3TypeInstruction(instructionWord).bReg;

			switch(opcode){
				case 0x11 : instruction = Instruction::JR; return;
				case 0x12 : instruction = Instruction::JALR; return;
			}
			break;
		}

		case InstructionType::RI : {
			auto [immediate, dReg, aReg] = extractRITypeInstruction(instructionWord);
			this->immediate = immediate;
			this->dReg = dReg;
			this->aReg = aReg;

			switch(opcode){
				case 0x06 : instruction = Instruction::MOVHI; return;
				case 0x21 : instruction = Instruction::LWZ; return;
				case 0x22 : instruction = Instruction::LWS; return;
				case 0x23 : instruction = Instruction::LBZ; return;
				case 0x24 : instruction = Instruction::LBS; return;
				case 0x25 : instruction = Instruction::LHZ; return;
				case 0x26 : instruction = Instruction::LHS; return;
				case 0x27 : instruction = Instruction::ADDI; return;
				case 0x28 : instruction = Instruction::ADDIC; return;
				case 0x29 : instruction = Instruction::ANDI; return;
				case 0x2A : instruction = Instruction::ORI; return;
				case 0x2B : instruction = Instruction::XORI; return;
				case 0x2C : instruction = Instruction::MULI; return;
				case 0x2D : instruction = Instruction::MFSPR; return;
			}
			break;
		}

		case InstructionType::RI2 : {
			auto [immediate, aReg, bReg] = extractRI2TypeInstruction(instructionWord);
			this->immediate = immediate;
			this->aReg = aReg;
			this->bReg = bReg;

			switch(opcode){
				case 0x30 : instruction = Instruction::MTSPR; return;
				case 0x35 : instruction = Instruction::SW; return;
				case 0x36 : instruction = Instruction::SB; return;
				case 0x37 : instruction = Instruction::SH; return;
			}
			break;
		}

		case InstructionType::RSF : {
			auto [functionCode, aReg, bReg] = extractRSFTypeInstruction(instructionWord);
			this->functionCode = functionCode;
			this->aReg = aReg;
			this->bReg = bReg;

			switch(opcode){
				case 0x39 : {
					switch(functionCode){
						case 0x0 : instruction = Instruction::SFEQ; return;
						case 0x1 : instruction = Instruction::SFNE; return;
						case 0x2 : instruction = Instruction::SFGTU; return;
						case 0x3 : instruction = Instruction::SFGEU; return;
						case 0x4 : instruction = Instruction::SFLTU; return;
						case 0x5 : instruction = Instruction::SFGTS; return;
						case 0xa : instruction = Instruction::SFGTS; return;
						case 0xb : instruction = Instruction::SFGES; return;
						case 0xc : instruction = Instruction::SFLTS; return;
						case 0xd : instruction = Instruction::SFLES; return;
					}
				}
			}
			break;
		}

		case InstructionType::RSFI : {
			auto [immediate, functionCode, aReg] = extractRSFITypeInstruction(instructionWord);
			this->functionCode = functionCode;
			this->immediate = immediate;
			this->aReg = aReg;

			switch(opcode){

				case 0x2f : {
					switch(functionCode){
						case 0x0 : instruction = Instruction::SFEQI; return;
						case 0x1 : instruction = Instruction::SFNEI; return;
						case 0x2 : instruction = Instruction::SFGTUI; return;
						case 0x3 : instruction = Instruction::SFGEUI; return;
						case 0x4 : instruction = Instruction::SFLTUI; return;
						case 0x5 : instruction = Instruction::SFGTSI; return;
						case 0xa : instruction = Instruction::SFGTSI; return;
						case 0xb : instruction = Instruction::SFGESI; return;
						case 0xc : instruction = Instruction::SFLTSI; return;
						case 0xd : instruction = Instruction::SFLESI; return;
					}
				}
			}
			break;
		}

		case InstructionType::END_MARKER : {
			return;
		}
	}
	
	throw IllegalInstruction("unrecognized instruction: " + std::to_string(instructionWord));
}