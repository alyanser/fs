/* rv64-emu -- Simple 64-bit RISC-V simulator
 *
 *    inst-decoder.h - RISC-V instruction decoder.
 *
 * Copyright (C) 2016,2019  Leiden University, The Netherlands.
 */

#ifndef __INST_DECODER_H__
#define __INST_DECODER_H__

#include "reg-file.h"

#include <stdexcept>
#include <cstdint>
#include <iostream>

static const int INSTRUCTION_SIZE = 4;

enum class Register : RegNumber {
	R0,
	R1,
	R2,
	R3,
	R4,
	R5,
	R6,
	R7,
	R8,
	R9,
	R10,
	R11,
	R12,
	R13,
	R14,
	R15,
	R16,
	R17,
	R18,
	R19,
	R20,
	R21,
	R22,
	R23,
	R24,
	R25,
	R26,
	R27,
	R28,
	R29,
	R30,
	R31
};

std::ostream &
operator<<(std::ostream & os, const Register reg);

enum class InstructionType {
	I,
	R1,
	R2,
	R3,
	RI,
	RI2,
	RSF,
	RSFI,
	END_MARKER
};

enum class Instruction {
	J,
	JAL,
	BNF,
	BF,
	NOP,
	MOVHI,
	SYS,
	RFE,
	JR,
	JALR,
	LWZ,
	LWS,
	LBZ,
	LBS,
	LHZ,
	LHS,
	ADDI,
	ADDIC,
	ANDI,
	ORI,
	XORI,
	MULI,
	MFSPR,
	SLLI,
	SRLI,
	SRAI,
	MTSPR,
	SW,
	SB,
	SH,
	ADD,
	ADDC,
	SUB,
	AND,
	OR,
	XOR,
	MUL,
	SLL,
	SRL,
	SRA,
	MULU,
	SFEQ,
	SFNE,
	SFGTU,
	SFGEU,
	SFLTU,
	SFLEU,
	SFGTS,
	SFGES,
	SFLTS,
	SFLES,
	SFEQI,
	SFNEI,
	SFGTUI,
	SFGEUI,
	SFLTUI,
	SFLEUI,
	SFGTSI,
	SFGESI,
	SFLTSI,
	SFLESI,
	ROR,
	DIV,
	DIVU,
	CMOV
};

std::ostream &
operator<<(std::ostream & os, const Instruction instruction);

/* Exception that should be thrown when an illegal instruction
 * is encountered.
 */
class IllegalInstruction : public std::runtime_error
{
  public:
    explicit IllegalInstruction(const std::string &what)
      : std::runtime_error(what)
    { }

    explicit IllegalInstruction(const char *what)
      : std::runtime_error(what)
    { }
};

/* InstructionDecoder component to be used by class Processor */
class InstructionDecoder
{
  public:
    void                setInstructionWord(const uint32_t instructionWord);
    uint32_t            getInstructionWord() const;
    RegNumber           getA() const;
    RegNumber           getB() const;
    RegNumber           getD() const;
    uint8_t getOpcode() const;
    uint32_t getImmediate() const;
    uint8_t getFunctionCode() const;
    InstructionType getInstructionType() const;
    Instruction getInstruction() const;

  private:
    void decode();

    uint32_t instructionWord{};
    uint32_t immediate{};
    uint16_t functionCode{};
		InstructionType instructionType{};
		Instruction instruction{};
    uint8_t opcode{};
    Register aReg{};
    Register bReg{};
    Register dReg{};

    friend std::ostream &operator<<(std::ostream &os, const InstructionDecoder &decoder);
};

#endif /* __INST_DECODER_H__ */
