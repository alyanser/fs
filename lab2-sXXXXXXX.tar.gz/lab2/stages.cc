/* rv64-emu -- Simple 64-bit RISC-V simulator
 *
 *    stages.cc - Pipeline stages
 *
 * Copyright (C) 2016-2020  Leiden University, The Netherlands.
 */

#include "stages.h"

#include <iostream>
#include <optional>

/*
 * Instruction fetch
 */

void
InstructionFetchStage::propagate()
{
  try
    {
      instructionMemory.setSize(4);
      instructionMemory.setAddress(PC);
      instructionWord = instructionMemory.getValue();

      if (instructionWord == TestEndMarker)
        throw TestEndMarkerEncountered(PC);
    }
  catch (TestEndMarkerEncountered &e)
    {
      throw;
    }
  catch (std::exception &e)
    {
      throw InstructionFetchFailure(PC);
    }
}

void
InstructionFetchStage::clockPulse()
{
  if_id.PC = PC += 4;
  if_id.instructionWord = instructionWord;
}

/*
 * Instruction decode
 */

void
dump_instruction(std::ostream &os, const uint32_t instructionWord,
                 const InstructionDecoder &decoder);

void
InstructionDecodeStage::propagate()
{
  PC = if_id.PC;
  decoder.setInstructionWord(if_id.instructionWord);

  /* debug mode: dump decoded instructions to cerr.
   * In case of no pipelining: always dump.
   * In case of pipelining: special case, if the PC == 0x0 (so on the
   * first cycle), don't dump an instruction. This avoids dumping a
   * dummy instruction on the first cycle when ID is effectively running
   * uninitialized.
   */
  if (debugMode && (! pipelining || (pipelining && PC != 0x0)))
    {
      /* Dump program counter & decoded instruction in debug mode */
      auto storeFlags(std::cerr.flags());

      std::cerr << std::hex << std::showbase << PC << "\t";
      std::cerr.setf(storeFlags);

      std::cerr << decoder << std::endl;
    }

     switch(decoder.getInstructionType()){

      case InstructionType::I : {
        immediate = decoder.getImmediate();
        break;
      }

      case InstructionType::R1 : {
        aRegNum = decoder.getA();
        bRegNum = decoder.getB();
        dRegNum = decoder.getD();
        regfile.setRS1(*aRegNum);
        regfile.setRS2(*bRegNum);
        regfile.setRD(*dRegNum);
        break;
      }

      case InstructionType::R2 : {
        aRegNum = decoder.getA();
        bRegNum = decoder.getD();
        immediate = decoder.getImmediate();
        regfile.setRS1(*aRegNum);
        regfile.setRD(*dRegNum);
        break;
      }

      case InstructionType::R3 : {
        bRegNum = decoder.getB();
        regfile.setRS2(*bRegNum);
        break;
      }

      case InstructionType::RI : {
        immediate = decoder.getImmediate();
        aRegNum = decoder.getA();
        dRegNum = decoder.getD();
        regfile.setRS1(*aRegNum);
        regfile.setRD(*dRegNum);
        break;
      }

      case InstructionType::RI2 : {
        immediate = decoder.getImmediate();
        aRegNum = decoder.getA();
        bRegNum = decoder.getB();
        regfile.setRS1(*aRegNum);
        regfile.setRS2(*bRegNum);
        break;
      }

      case InstructionType::RSF : {
        aRegNum = decoder.getA();
        bRegNum = decoder.getB();
        regfile.setRS1(*aRegNum);
        regfile.setRS2(*bRegNum);
        break;
      }

      case InstructionType::RSFI : {
        immediate = decoder.getImmediate();
        aRegNum = decoder.getA();
        regfile.setRS1(*aRegNum);
        break;
      }

      case InstructionType::END_MARKER : break;
    }
}

void InstructionDecodeStage::clockPulse()
{
  /* ignore the "instruction" in the first cycle. */
  if (! pipelining || (pipelining && PC != 0x0))
    ++nInstrIssued;

  id_ex.PC = PC;
  regfile.setWriteEnable(false);

  if(aRegNum){
    id_ex.aRegVal = regfile.getReadData1();
  }

  if(bRegNum){
    id_ex.bRegVal = regfile.getReadData2();
  }

  if(immediate){
    id_ex.immediate = *immediate;
  }

  id_ex.op = op;
  id_ex.instructionType = decoder.getInstructionType();
  id_ex.instruction = decoder.getInstruction();
}

/*
 * Execute
 */

void
ExecuteStage::propagate()
{
  PC = id_ex.PC;

  switch(id_ex.instructionType){
    case InstructionType::I : { // don't need alu for I type instructions
      break;
    }

    case InstructionType::R1 : {
      alu.setA(id_ex.aRegVal);
      alu.setB(id_ex.bRegVal);

      switch(id_ex.instruction){
        case Instruction::ADD : {
          alu.setOp(ALUOp::ADD);
          break;
        }

        case Instruction::SUB : {
          alu.setOp(ALUOp::SUB);
          break;
        }

        case Instruction::DIV : {
          alu.setOp(ALUOp::DIV);
          break;
        }

        case Instruction::MUL : {
          alu.setOp(ALUOp::MUL);
          break;
        }

        case Instruction::OR : {
          alu.setOp(ALUOp::OR);
          break;
        }

        case Instruction::XOR : {
          alu.setOp(ALUOp::XOR);
          break;
        }

        case Instruction::AND : {
          alu.setOp(ALUOp::AND);
          break;
        }
        case Instruction::NOP : {
          alu.setOp(ALUOp::NOP);
          break;
        }
        case Instruction::SLL : {
          alu.setOp(ALUOp::SHL);
          break;
        }
        case Instruction::SRL : {
          alu.setOp(ALUOp::SHR);
          break;
        }
      }
      break;
    }

    case InstructionType::R2 : {
      alu.setA(id_ex.aRegVal);
      alu.setB(id_ex.immediate);

      switch(id_ex.instruction){
        case Instruction::SLLI : {
          alu.setOp(ALUOp::SHL);
          break;
        }

        case Instruction::SRLI : {
          alu.setOp(ALUOp::SHR);
          break;
        }
      }
      break;
    }

    case InstructionType::RI : {
      alu.setA(id_ex.aRegVal);
      alu.setB(static_cast<int16_t>(id_ex.immediate));

      switch(id_ex.instruction){
        case Instruction::ADDI : {
          alu.setOp(ALUOp::ADD);
          break;
        }
        case Instruction::ANDI : {
          alu.setOp(ALUOp::AND);
          break;
        }
        case Instruction::ORI : {
          alu.setOp(ALUOp::OR);
          break;
        }
        case Instruction::XORI : {
          alu.setOp(ALUOp::XOR);
          break;
        }
        case Instruction::MULI : {
          alu.setOp(ALUOp::MUL);
          break;
        }

        case Instruction::LWZ : {
          alu.setOp(ALUOp::ADD);
          ex_m.memoryOperation = true;
          break;
        }
      }
      break;
    }

    case InstructionType::RI2 : {
      alu.setA(id_ex.aRegVal);
      alu.setB(id_ex.immediate);

      switch(id_ex.instruction){
        case Instruction::SW : {
          ex_m.memoryOperation = true;
          ex_m.regDeferVal = id_ex.bRegVal;
          alu.setOp(ALUOp::ADD);
          break;
        }

        case Instruction::SB : {
          ex_m.memoryOperation = true;
          ex_m.regDeferVal = id_ex.bRegVal;
          alu.setOp(ALUOp::ADD);
          break;
        }
      }
      break;
    }

    case InstructionType::RSF : {
      break;
    }

    case InstructionType::RSFI : {
      break;
    }
  }

  ex_m.instructionType = id_ex.instructionType;
  ex_m.instruction = id_ex.instruction;
}

void
ExecuteStage::clockPulse()
{
  ex_m.PC = PC;

  switch(ex_m.instructionType){
    case InstructionType::R1 : [[fallthrough]];
    case InstructionType::R2 : [[fallthrough]];
    case InstructionType::RI : [[fallthrough]];
    case InstructionType::RI2 : {
      ex_m.aluResult = alu.getResult();
      break;
    }
  }
}

/*
 * Memory
 */

void
MemoryStage::propagate()
{
  PC = ex_m.PC;

  if(ex_m.memoryOperation){
    dataMemory.setAddress(ex_m.aluResult);

    switch(ex_m.instruction){

      case Instruction::LWZ : {
        m_wb.readOperation = true;
        dataMemory.setSize(4);
        dataMemory.setReadEnable(true);
        dataMemory.setWriteEnable(false);
        break;
      }

      case Instruction::SW : {
        m_wb.readOperation = false;
        dataMemory.setSize(4);
        dataMemory.setReadEnable(false);
        dataMemory.setWriteEnable(true);
        dataMemory.setDataIn(ex_m.regDeferVal);
        break;
      }
      case Instruction::SB : {
        m_wb.readOperation = false;
        dataMemory.setSize(1);
        dataMemory.setReadEnable(false);
        dataMemory.setWriteEnable(true);
        dataMemory.setDataIn(ex_m.regDeferVal);
        break;
      }
    }
    return;
  }
}

void
MemoryStage::clockPulse()
{
  m_wb.PC = PC;

  if(ex_m.memoryOperation){
    if(m_wb.readOperation){
      m_wb.output = dataMemory.getDataOut(true);
    }else{
      dataMemory.clockPulse();
    }
  }else{
    m_wb.output = ex_m.aluResult;
  }
}

/*
 * Write back
 */

void
WriteBackStage::propagate()
{
  if (! pipelining || (pipelining && m_wb.PC != 0x0))
    ++nInstrCompleted;

  if(!m_wb.memoryOperation || m_wb.readOperation){
    regfile.setWriteEnable(true);
    regfile.setWriteData(m_wb.output);
  }
}

void
WriteBackStage::clockPulse()
{
  regfile.clockPulse();
}
