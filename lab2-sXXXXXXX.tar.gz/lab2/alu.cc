/* rv64-emu -- Simple 64-bit RISC-V simulator
 *
 *    alu.h - ALU component.
 *
 * Copyright (C) 2016,2018  Leiden University, The Netherlands.
 */

#include "alu.h"

#include "inst-decoder.h"

#ifdef _MSC_VER
/* MSVC intrinsics */
#include <intrin.h>
#endif


ALU::ALU()
  : A(), B(), op()
{
}

RegValue
ALU::getResult()
{
  switch (op)
    {
      case ALUOp::NOP: return 0;
      case ALUOp::DIV: {
				if(!B){
					throw IllegalInstruction("ALU: attemtpt to divide by zero");
				}

				return A / B;
			}
      case ALUOp::MUL: return A * B;
      case ALUOp::SUB: return A - B;
      case ALUOp::ADD: return A + B;
      case ALUOp::OR: return A | B;
      case ALUOp::XOR: return A ^ B;
      case ALUOp::AND: return A & B;
      case ALUOp::SHL: return A >> B;
      case ALUOp::SHR: return A << B;
		}

	throw IllegalInstruction("Unimplemented or unknown ALU operation");
}
